﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MiniWater
{
    class Neighbourhood
    {
        public List<Household> Households;

        public Neighbourhood(int size, int days, int seed)
        {
            Households = new List<Household>();

            Console.WriteLine($"Creating new Neighbourhood of {size} Households each of {days} days");
            float[] occupantDistribution = new float[] { 11.1111111111111f, 45.1388888888889f, 14.9305555555556f, 18.4027777777778f, 7.63888888888889f, 2.77777777777778f };
            List<string> scalable = new List<string> { "Faucet", "Shower", "Bathtub" };
            List<string> unscalable = new List<string> { "Toilet", "Dishwasher", "ClothesWasher" };
            Dictionary<int, Dictionary<string, List<float[]>>> signaturesScalable = new Dictionary<int, Dictionary<string, List<float[]>>>();
            Dictionary<string, List<float[]>> signaturesUnscalable = new Dictionary<string, List<float[]>>();
            Random randomVar = new Random(seed);
            MatlabTools.ReseedMatlab(seed);

            foreach (string name in unscalable)
            {
                List<float[]> activitySigs = new List<float[]>();
                activitySigs.AddRange(StreamTools.GetSignatures()[name]);
                if (StreamTools.GetSignatures().ContainsKey("Eff" + name))
                    activitySigs.AddRange(StreamTools.GetSignatures()["Eff" + name]);
                for (int j = 0; j < activitySigs.Count; j++) activitySigs[j] = activitySigs[j].Skip(1).Take(activitySigs[j].Length - 2).ToArray();
                signaturesUnscalable.Add(name, activitySigs);
            }

            for (int i = 1; i <= 6; i++)
            {
                signaturesScalable.Add(i, new Dictionary<string, List<float[]>>());
                foreach (string name in scalable)
                {
                    List<float[]> activitySigs = new List<float[]>();
                    for (int j = 0; j < 20; j++)
                    {
                        float[] sig = StreamTools.GenerateRandomSignatureFromDatabase(name, i, randomVar);
                        sig = sig.Skip(1).Take(sig.Length - 2).ToArray();
                        activitySigs.Add(sig);
                    }
                    signaturesScalable[i].Add(name, activitySigs);
                }
            }

            Households.AddRange(AddMoreHouseholds(size, days, signaturesScalable, signaturesUnscalable, occupantDistribution, randomVar));
        }

        List<Household> AddMoreHouseholds(int count, int days, Dictionary<int, Dictionary<string, List<float[]>>> scalable, Dictionary<string, List<float[]>> unscalable, float[] occupantDistribution, Random randomVar)
        {
            var households = new List<Household>();

            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("\nAdding new Household...");
                int hhSize = StreamTools.GetIndexFromDistribution(occupantDistribution, randomVar) + 1;
                households.Add(new Household(days, hhSize, scalable[hhSize], unscalable, occupantDistribution, randomVar));
            }
            return households;
        }
    }
}
