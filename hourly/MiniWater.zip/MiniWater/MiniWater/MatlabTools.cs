﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MiniWater
{
    static class MatlabTools
    {
        static MLApp.MLApp matlab;
        static readonly DirectoryInfo projectDir;
        static string datapath;
        static string scriptspath;

        static MatlabTools()
        {
            DirectoryInfo projectDir = new DirectoryInfo(Environment.CurrentDirectory);
            while (projectDir.Name != "MiniWater") projectDir = projectDir.Parent;

            matlab = new MLApp.MLApp();
            datapath = $@"{projectDir.FullName}\MATLAB_Data";
            scriptspath = $@"{projectDir.FullName}\MATLAB_Scripts";

            matlab.Execute("rehash");
            matlab.Execute($"addpath '{datapath}'");
            matlab.Execute($"addpath '{scriptspath}'");
            matlab.Execute("load database.mat;");
        }

        public static void ReseedMatlab(int? seed)
        {
            if (seed != null) matlab.Execute($"rng({Math.Abs((int)seed)})");
        }

        public static float[][] GetDistributionValues(int count, string activityName, string distributionName, int householdSize)
        {
            string result;
            float[][] output = null;
            switch (distributionName)
            {
                case "NumEvents":
                    output = new float[1][] { new float[count] };
                    for (int i = 0; i < count; i++)
                    {
                        result = matlab.Execute($"random(database.UseProbabilities.{activityName}.NumberOfEventsPerDay{{1,{householdSize}}}{{1,1}})");
                        output[0][i] = (float)Math.Round(GetDecimalsFromString(result)[0]);
                    }
                    break;
                case "DurVol":
                    output = new float[2][] { new float[count], new float[count] };
                    for (int i = 0; i < count; i++)
                    {
                        matlab.Execute($"distDurVolume = database.UseProbabilities.{activityName}.GMDurationAndVolume{{1,{householdSize}}};");
                        result = matlab.Execute($"exp(random(distDurVolume))");
                        var vals = GetDecimalsFromString(result);
                        output[0][i] = (int)Math.Max(1, Math.Round(vals[0]));
                        output[1][i] = vals[1];
                    }
                    break;
                case "StartTime":
                    output = new float[1][] { new float[count] };
                    for (int i = 0; i < count; i++)
                    {
                        matlab.Execute($"tempTimeStart = datevec(random(database.UseProbabilities.{activityName}.EventStartTime{{1,{householdSize}}}{{1,1}}));");
                        result = matlab.Execute($"360*tempTimeStart(4) + 6*tempTimeStart(5) + round(tempTimeStart(6)/10)");
                        output[0][i] = GetDecimalsFromString(result)[0];
                    }
                    break;
            }
            return output;
        }

        public static float[] GetTruncatedDistributionValues(Random random, int count, string activityName, string distributionName, int householdSize, List<Tuple<float, float>> truncations)
        {
            if (!(distributionName == "NumEvents" || distributionName == "StartTime")) throw new Exception("Distribution name must be \"NumEvents\" or \"StartTime\"");

            float[] values = new float[count];

            int divisions = 0;
            if (distributionName == "NumEvents")
            {
                distributionName = "NumberOfEventsPerDay";
                string result = matlab.Execute("max(database.UseProbabilities.StToilet.NumberOfEventsPerDay{1, 1}{1, 1}.InputData.data)");
                divisions = (int)Math.Floor((GetDecimalsFromString(result)[0] + 1) * 1.2);
            }
            else if (distributionName == "StartTime")
            {
                distributionName = "EventStartTime";
                divisions = 24 * 60 * 6;
            }

            object output;
            matlab.Feval("convertDistributionIntoPDF", 1, out output, datapath, divisions, activityName, distributionName, householdSize);

            var objects = output as object[];
            var distObject = objects[0] as double[,];
            float[] dist = new float[divisions];
            for (int i = 0; i < divisions; i++) dist[i] = Convert.ToSingle(distObject[0, i]);

            foreach (Tuple<float, float> trunc in truncations)
            {
                int minIndex = (int)Math.Round(Math.Max(0, trunc.Item1) * divisions);
                int maxIndex = (int)Math.Round(Math.Min(1, trunc.Item2) * divisions);
                if (minIndex >= maxIndex) continue;
                for (int i = minIndex; i < maxIndex; i++) dist[i] = 0;
            }

            for (int i = 0; i < count; i++)
            {
                values[i] = StreamTools.GetIndexFromDistribution(dist, random);
            }

            return values;
        }

        public static Tuple<int[], float[]> GetPeakOrOffTimeMinutes(string activityName, float offTimeThreshold, int householdSize, bool isPeak)
        {
            if (offTimeThreshold <= 0 || offTimeThreshold >= 1) throw new Exception("Threshold value must be between 0 and 1");

            int minutesInDay = 24 * 60;

            object output;
            matlab.Feval("convertDistributionIntoPDF", 1, out output, datapath, minutesInDay, activityName, "EventStartTime", householdSize);

            var objects = output as object[];
            var distObject = objects[0] as double[,];

            int[] minutes = new int[minutesInDay];
            float[] dist = new float[minutesInDay];
            for (int i = 0; i < minutesInDay; i++)
            {
                minutes[i] = i;
                dist[i] = Convert.ToSingle(distObject[0, i]);
            }

            Array.Sort(dist, minutes);

            dist = StreamTools.ScaleSignatureHeight(dist, 1);

            float runningSum = 0;
            int finalIndex = 0;
            for (int i = 0; i < minutesInDay; i++)
            {
                runningSum += dist[i];
                if (runningSum >= offTimeThreshold)
                {
                    finalIndex = i;
                    break;
                }
            }

            if (!isPeak)
            {
                minutes = minutes.Take(finalIndex + 1).ToArray();
                dist = dist.Take(finalIndex + 1).ToArray();
            }
            else
            {
                minutes = minutes.Skip(finalIndex + 1).ToArray();
                dist = dist.Skip(finalIndex + 1).ToArray();
            }

            return new Tuple<int[], float[]>(minutes, dist);
        }

        public static Dictionary<string, List<float[]>> LoadSignatures()
        {
            Dictionary<string, List<float[]>> signatures = new Dictionary<string, List<float[]>>();

            object output;
            matlab.Feval("loadSignatures", 2, out output, datapath);

            var objects = output as object[];
            var names = objects[0] as object[,];
            var allSigs = objects[1] as object[,];

            for (int i = 0; i < names.Length; i++)
            {
                List<float[]> finalSigs = new List<float[]>();
                string name = names[i, 0] as string;
                var sigs = allSigs[0, i] as object[,];
                for (int j = 0; j < sigs.Length; j++)
                {
                    var sig = sigs[0, j] as double[,];
                    float[] finalSig = new float[sig.Length];
                    for (int k = 0; k < sig.Length; k++) finalSig[k] = (float)sig[0, k];
                    finalSigs.Add(finalSig);
                }

                signatures.Add(name, finalSigs);
            }
            return signatures;
        }

        private static float[] GetDecimalsFromString(string input)
        {
            var matches = Regex.Matches(input, @"\d*\.?\d+");
            float[] floats = new float[matches.Count];
            for (int i = 0; i < matches.Count; i++) floats[i] = float.Parse(matches[i].Value);
            return floats;
        }
    }
}
