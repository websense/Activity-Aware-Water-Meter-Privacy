﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;

namespace MiniWater
{
    public static class StreamTools
    {
        const int seconds10PerDay = 360 * 24;
        const string distributionFolderPath = "../Database/Distributions/";
        const string signatureFolderPath = "../Database/Signatures/";
        private static readonly Dictionary<string, List<float[]>> signatures;

        static StreamTools()
        {
            signatures = MatlabTools.LoadSignatures();
        }

        public static Dictionary<string, List<float[]>> GetSignatures()
        {
            return signatures;
        }

        public static float[] GenerateRandomSignatureFromDatabase(string activityName, int householdSize, Random random)
        {
            if (signatures[activityName].Count == 0) throw new Exception($"No signatures found for {activityName}");
            var durVol = MatlabTools.GetDistributionValues(1, activityName, "DurVol", householdSize);
            int duration = (int)durVol[0][0];
            float volume = durVol[1][0];
            int sigId = random.Next(signatures[activityName].Count);
            float[] signature = signatures[activityName][sigId];
            signature = ScaleSignatureWidth(signature, duration);
            signature = ScaleSignatureHeight(signature, volume);
            if (signature.Any(v => float.IsNaN(v))) throw new Exception("Signature generated NaN");
            return signature;
        }

        public static float[] ScaleSignatureHeight(float[] signature, float newTotal)
        {
            float sigSum = signature.Sum();
            float scalingFactor = newTotal / sigSum;
            float[] newSig = new float[signature.Count()];
            for (int i = 0; i < signature.Count(); i++) newSig[i] = signature[i] * scalingFactor;
            return newSig;
        }

        public static float[] ScaleSignatureWidth(float[] signature, int newWidth)
        {
            if (newWidth == signature.Count()) return signature;

            float[] newSig = new float[newWidth + 2];
            float scalingFactor = (1.0f * signature.Count() - 1) / (newWidth + 1);
            for (int i = 1; i < newWidth + 1; i++)
            {
                float newPoint = (float)Math.Round(scalingFactor * i, 5);
                int indexFloor = (int)Math.Floor(newPoint);
                int indexCeil = (int)Math.Ceiling(newPoint);
                if (newPoint % 1 == 0) newSig[i] = signature[(int)newPoint];
                else newSig[i] = signature[indexCeil] * (newPoint - indexFloor) + signature[indexFloor] * (indexCeil - newPoint);
            }
            return newSig;
        }

        public static float[] CombineMultipleStreams(List<float[]> streams)
        {
            if (streams.Count == 0) return null;
            if (streams.Any(s => s.Length != streams.First().Length)) throw new Exception("Streams in the list are not all the same length");

            int streamLength = streams.First().Length;
            float[] totalStream = new float[streamLength];
            for (int i = 0; i < streams.Count(); i++)
            {
                for (int j = 0; j < streamLength; j++)
                {
                    totalStream[j] += streams[i][j];
                }
            }

            return totalStream;
        }

        public static int GetIndexFromDistribution(float[] distribution, Random random)
        {
            var x = distribution.Sum();
            double r = random.NextDouble() * distribution.Sum();
            double runningTotal = 0;
            for (int i = 0; i < distribution.Length; i++)
            {
                runningTotal += distribution[i];
                if (runningTotal >= r) return i;
            }
            return -1; //Should be impossible to reach here
        }

        public static float[] GenerateValuesFromDistribution1D(string distName, string activityName, int count, int householdSize)
        {
            float[] values = null;
            if (distName == "NumEvents")
            {
                values = MatlabTools.GetDistributionValues(count, activityName, "NumEvents", householdSize)[0];
            }
            else if (distName == "StartTime")
            {
                values = MatlabTools.GetDistributionValues(count, activityName, "StartTime", householdSize)[0];
                Array.Sort(values);
            }
            return values;
        }

        public static void SaveStream(List<float> data, string path, string name)
        {
            string str = "";
            foreach (var d in data) str += d + "\n";
            File.WriteAllText(path + "\\" + name, str);
        }

        public static void SaveStream(List<int> data, string path, string name)
        {
            string str = "";
            foreach (var d in data) str += d + "\n";
            File.WriteAllText(path + "\\" + name, str);
        }

        public static void SerializeItem(string path, object item)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream fs = new FileStream(path, FileMode.Create);
            using (fs)
            {
                formatter.Serialize(fs, item);
            }
        }

        public static object DeserializeItem(string path)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream fs = new FileStream(path, FileMode.Open);
            using (fs) return formatter.Deserialize(fs);
        }
    }
}
