function [names, signatures] = loadSignatures(datapath)

addpath(datapath);
load database.mat;

signatures = {};
names = fieldnames(database.signatures);
for i = 1:length(names)
    name = names{i};
    signatures{end+1} = database.signatures.(name);
end

end