﻿function array = convertDistributionIntoPDF(datapath, divisions, activityName, distributionName, HHsize)

addpath(datapath);
load database.mat;

dist = database.UseProbabilities.(activityName).(distributionName){1, HHsize}{1, 1};
step = 1 / double(divisions);

x = step:step:1;
array = pdf(dist, x);

end