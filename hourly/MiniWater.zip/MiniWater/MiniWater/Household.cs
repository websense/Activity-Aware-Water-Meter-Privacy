﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace MiniWater
{
    class Household
    {
        int Days;
        int HouseholdSize;
        Random RandomVar;
        public Dictionary<string, List<float[]>> Signatures;
        public Dictionary<string, ActivityLog> Logs;
        public Dictionary<string, float[]> ActivityStreams;

        public float[] RawStream;

        public Household(int days, int householdSize, Dictionary<string, List<float[]>> scalable, Dictionary<string, List<float[]>> unscalable, float[] occupantDistribution, Random randomVar)
        {
            Days = days;
            HouseholdSize = householdSize;
            RandomVar = randomVar;
            Signatures = new Dictionary<string, List<float[]>>();
            Logs = new Dictionary<string, ActivityLog>();
            ActivityStreams = new Dictionary<string, float[]>();
            foreach (var kvp in scalable) Signatures.Add(kvp.Key, kvp.Value);
            foreach (var kvp in unscalable) Signatures.Add(kvp.Key, kvp.Value);

            RawStream = new float[days * 24 * 360];
            Logs = new Dictionary<string, ActivityLog>();
            ActivityStreams = new Dictionary<string, float[]>();

            foreach (string name in Signatures.Keys)
            {
                float[] activityStream;
                Console.WriteLine($"Adding {name} Activity to Current Household");
                Logs.Add(name, CreateActivityStreamAndAddToTotal(RawStream, name, Signatures[name], out activityStream));
                ActivityStreams.Add(name, activityStream);
            }
        }

        private ActivityLog CreateActivityStreamAndAddToTotal(float[] rawStream, string name, List<float[]> signatures, out float[] activityStream)
        {
            ActivityLog activityLog = new ActivityLog();
            activityStream = new float[rawStream.Length];
            float[] numEvents = StreamTools.GenerateValuesFromDistribution1D("NumEvents", name, Days, HouseholdSize);
            activityLog.NumEvents = numEvents;

            for (int day = 0; day < Days; day++)
            {
                int numEvent = (int)numEvents[day];
                float[] floatTimeStarts = StreamTools.GenerateValuesFromDistribution1D("StartTime", name, numEvent, HouseholdSize);
                int[] timeStarts = new int[floatTimeStarts.Length];
                for (int i = 0; i < floatTimeStarts.Length; i++) timeStarts[i] = (int)floatTimeStarts[i];

                int[] durations = new int[numEvent];
                float[] volumes = new float[numEvent];
                int[] signatureRefs = new int[numEvent];

                for (int i = 0; i < numEvent; i++)
                {
                    int sigId = RandomVar.Next(signatures.Count);
                    float[] signature = signatures[sigId];
                    signatureRefs[i] = sigId;
                    durations[i] = signature.Length;
                    volumes[i] = signature.Sum();
                    int startID = day * 24 * 360 + timeStarts[i];
                    for (int j = startID; j < startID + signature.Length && j < rawStream.Length; j++)
                    {
                        rawStream[j] += signature[j - startID];
                        activityStream[j] += signature[j - startID];
                    }
                }

                activityLog.TimeStarts.Add(timeStarts);
                activityLog.Durations.Add(durations);
                activityLog.Volumes.Add(volumes);
            }
            return activityLog;
        }

        public void PrintRawStreamToFile(string path)
        {
            Console.WriteLine($"Printing Raw Stream to File: {path}");
            AppendArrayToFile(path, RawStream);
        }

        public void PrintActivityToFile(string path, string name)
        {
            Console.WriteLine($"Printing {name} Activity Stream to File: {path}");
            float[] activityStream = ActivityStreams[name];
            AppendArrayToFile(path, activityStream);
        }

        void AppendArrayToFile(string path, float[] array)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var d in array) sb.Append($"{d},");
            sb.Remove(sb.Length - 1, 1);
            sb.Append("\n");
            File.AppendAllText(path, sb.ToString());
        }
    }
    public class ActivityLog
    {
        public float[] NumEvents { get; set; }
        public List<int[]> SignatureRefs { get; set; }
        public List<int[]> Durations { get; set; }
        public List<float[]> Volumes { get; set; }
        public List<int[]> TimeStarts { get; set; }

        public ActivityLog()
        {
            SignatureRefs = new List<int[]>();
            Durations = new List<int[]>();
            Volumes = new List<float[]>();
            TimeStarts = new List<int[]>();
        }
    }
}
