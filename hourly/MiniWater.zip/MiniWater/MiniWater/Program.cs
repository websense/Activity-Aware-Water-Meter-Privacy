﻿using System;

//This code was based on the STREaM model based on cominola.
//Found at: https://github.com/acominola/STREaM, on the 3/10/21.
//The code has been adapted to generate the raw streams of entire neighbourhoods of households,
//with a few bug fixes (e.g. original code was able to generate empty signatures)

namespace MiniWater
{
    class Program
    {
        static string dir = "PUT FILE OUT DIRECTORY HERE";

        static void Main(string[] args)
        {
            //Example code to generate a neighbourhood of households
            //Params are number of houses, number of days, and a seed
            //For example, one household with a 10 day raw stream.
            Neighbourhood n = new Neighbourhood(1, 10, 100); 

            //Example code to print household raw streams to a file
            foreach(var h in n.Households)
            {
                h.PrintRawStreamToFile(dir + @"\raw.txt");
                foreach(var name in h.ActivityStreams.Keys)
                {
                    h.PrintActivityToFile(dir + @$"\{name}.txt", name);
                }
            }
        }
    }
}
